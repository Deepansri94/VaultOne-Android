# VaultOne Android

Android WebView APK wrapper for `VaultOne_document_details_fixed.html`.

## Source used
The app UI and existing offline-first logic are taken from `VaultOne_document_details_fixed.html`.

## Native Android additions
- WebView DOM storage + IndexedDB enabled.
- HTTPS-style local app origin (`https://vaultone.local`) so the HTML has a persistent origin suitable for IndexedDB.
- Native Android document sharing through the system share sheet using FileProvider.
- Native reminder notifications using Android NotificationChannel + AlarmManager.
- Android 13+ notification permission request.
- Portrait Android-first presentation.

## Build
Open this folder in Android Studio and use Gradle 9.5 / Android Gradle Plugin 9.3.0 with SDK 36 installed, then build `app > assembleDebug` or `assembleRelease`.

The current execution environment does not contain the Android SDK/Gradle toolchain, so an APK cannot be compiled here. The project is prepared as the Android build source.
