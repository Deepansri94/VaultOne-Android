# VaultOne WebView bridge methods are called by JavaScript.
-keepclassmembers class com.vaultone.app.MainActivity$VaultBridge { *; }
