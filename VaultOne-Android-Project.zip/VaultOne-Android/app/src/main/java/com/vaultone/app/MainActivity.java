package com.vaultone.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.webkit.*;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int NOTIFICATION_PERMISSION = 9001;
    private static final String CHANNEL_ID = "vaultone_reminders";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(11,14,22));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(7,10,18));
        setupWebView();
        createNotificationChannel();
    }

    private void setupWebView() {
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        WebView.setWebContentsDebuggingEnabled(false);
        webView.addJavascriptInterface(new VaultBridge(), "AndroidVault");
        webView.setWebViewClient(new LocalClient());
        webView.loadUrl("https://vaultone.local/index.html");
        setContentView(webView);
    }

    private class LocalClient extends WebViewClient {
        @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
            String path = Uri.parse(req.getUrl().toString()).getPath();
            if (path == null || path.equals("/")) path = "/index.html";
            if (path.equals("/index.html")) {
                try {
                    InputStream in = getAssets().open("index.html");
                    return new WebResourceResponse("text/html", "UTF-8", in);
                } catch (IOException ignored) {}
            }
            return super.shouldInterceptRequest(view, req);
        }
        @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return false;
        }
    }

    public class VaultBridge {
        @JavascriptInterface public void shareFile(String fileName, String mimeType, String base64) {
            runOnUiThread(() -> {
                try {
                    byte[] bytes = Base64.getDecoder().decode(base64);
                    File dir = new File(getCacheDir(), "shared");
                    if (!dir.exists() && !dir.mkdirs()) throw new IOException("Unable to create share cache");
                    File file = new File(dir, safeName(fileName));
                    try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); }
                    Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName()+".fileprovider", file);
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType(mimeType == null || mimeType.isEmpty() ? "application/octet-stream" : mimeType);
                    send.putExtra(Intent.EXTRA_STREAM, uri);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(send, "Share document"));
                } catch (Exception e) {
                    runJs("window.toast && window.toast('Native share failed: '+"+jsQuote(e.getMessage())+",true)");
                }
            });
        }
        @JavascriptInterface public void requestNotifications() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION);
                } else runJs("window.AndroidVaultNotificationsGranted && AndroidVaultNotificationsGranted()");
            });
        }
        @JavascriptInterface public void scheduleReminder(String id, String title, String description, String date, String time) {
            try {
                String t = (time == null || time.isEmpty()) ? "09:00" : time;
                long when = java.time.LocalDateTime.parse(date+"T"+t).atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli();
                if (when <= System.currentTimeMillis()) return;
                Intent i = new Intent(MainActivity.this, ReminderReceiver.class);
                i.putExtra("title", title); i.putExtra("description", description);
                PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, stableCode(id), i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                AlarmManager am = (AlarmManager)getSystemService(ALARM_SERVICE);
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            } catch (Exception ignored) {}
        }
        @JavascriptInterface public void cancelReminder(String id) {
            Intent i = new Intent(MainActivity.this, ReminderReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, stableCode(id), i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            ((AlarmManager)getSystemService(ALARM_SERVICE)).cancel(pi);
        }
        @JavascriptInterface public void lockVault() { runOnUiThread(() -> runJs("window.lockVault && lockVault()")); }
    }

    private int stableCode(String id) { return id == null ? 1 : (id.hashCode() & 0x7fffffff); }
    private String safeName(String n) { if (n == null || n.isEmpty()) n="document"; return n.replaceAll("[^a-zA-Z0-9._-]", "_"); }
    private String jsQuote(String s) { if (s == null) s="Unknown error"; return "'"+s.replace("\\","\\\\").replace("'","\\'").replace("\n"," ")+"'"; }
    private void runJs(String js) { if (webView != null) webView.post(() -> webView.evaluateJavascript(js, null)); }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL_ID, "VaultOne Reminders", NotificationManager.IMPORTANCE_HIGH);
            c.setDescription("Reminder alerts from VaultOne");
            c.enableVibration(true);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NOTIFICATION_PERMISSION) runJs("window.AndroidVaultNotificationsGranted && AndroidVaultNotificationsGranted()" );
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
